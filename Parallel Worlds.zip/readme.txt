What I completed:
1. At least one two-level hierarchical object (e.g. human arm).
2. At least one texture either procedurally generated or mapped.
3. At least one shader edited or designed from scratch to perform a clearly visible effect.
4. 360 degrees camera fly around using lookAt() and setMV().
5. Connection to real-time. You should make sure that your scene runs in real-time on fast enough
machines. Real-time means that one simulated second corresponds roughly to one real second.
6. You should display the frame rate of your program in the console window or the graphics window
once every 2 seconds.
7. Make and submit a movie of your animation. The movie should be about 512x512 and in a standard
format, such as mp4. Include a cover image (png or jpg) of 100x100 pixels. You may use any screen
capture program that is available.
8. Provide a readme.txt that describes what you have done, what you have omitted, and any other
information that will help the grader evaluation your work, including what is stated below.
9. Complexity: scene setup and design, movement of animated elements, and programming.
10. Creativity: story telling, scene design, object appearance and other artistic elements.
11. Quality: Attention to detail, modeling quality, rendering quality, motion control.
12. Programming style.


What I omitted: